#include <stdio.h>

int main() {
    int a = 10, b = 5, c;

    // Assignment operator
    c = a;
    printf("c = a: %d\n", c);

    // Addition assignment
    c += b;  // equivalent to c = c + b
    printf("c += b: %d\n", c);

    // Subtraction assignment
    c -= b;  // equivalent to c = c - b
    printf("c -= b: %d\n", c);

    // Multiplication assignment
    c *= b;  // equivalent to c = c * b
    printf("c *= b: %d\n", c);

    // Division assignment
    c /= b;  // equivalent to c = c / b
    printf("c /= b: %d\n", c);

    // Modulus assignment
    c %= b;  // equivalent to c = c % b
    printf("c %%= b: %d\n", c);  // %% to escape %

    return 0;
}