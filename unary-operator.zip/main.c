#include <stdio.h>

int main() {
    int a = 5;

    // Unary minus
    printf("Unary minus of a: %d\n", -a);

    // Unary plus (no change in this case)
    printf("Unary plus of a: %d\n", +a);

    // Increment operator (prefix)
    printf("Prefix increment of a: %d\n", ++a); // a is incremented to 6, then printed

    // Decrement operator (prefix)
    printf("Prefix decrement of a: %d\n", --a); // a is decremented back to 5, then printed

    // Increment operator (postfix)
    printf("Postfix increment of a: %d\n", a++); // a is printed as 5, then incremented to 6
    printf("After postfix increment, a: %d\n", a); // now a is 6

    // Decrement operator (postfix)
    printf("Postfix decrement of a: %d\n", a--); // a is printed as 6, then decremented to 5
    printf("After postfix decrement, a: %d\n", a); // now a is 5

    // Logical NOT
    printf("Logical NOT of (a != 0): %d\n", !(a != 0)); // if a is non-zero, !(a != 0) is false (0)

    return 0;
}