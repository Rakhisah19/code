#include <stdio.h>

int main() {
    int a = 1;  // true (non-zero)
    int b = 0;  // false (zero)

    // Logical AND
    printf("a && b: %d\n", a && b);  // returns 0 (false) because b is 0

    // Logical OR
    printf("a || b: %d\n", a || b);  // returns 1 (true) because a is 1

    // Logical NOT
    printf("!a: %d\n", !a);          // returns 0 (false) because a is 1
    printf("!b: %d\n", !b);          // returns 1 (true) because b is 0

    return 0;
}