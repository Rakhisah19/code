#include <stdio.h>

int main() {
    int a = 10, b = 5;

    // Assignment operator
    printf("Initial value of a: %d\n", a);

    // Addition assignment
    a += b;  // equivalent to a = a + b
    printf("After a += b, a: %d\n", a);

    // Subtraction assignment
    a -= b;  // equivalent to a = a - b
    printf("After a -= b, a: %d\n", a);

    // Multiplication assignment
    a *= b;  // equivalent to a = a * b
    printf("After a *= b, a: %d\n", a);

    // Division assignment
    a /= b;  // equivalent to a = a / b
    printf("After a /= b, a: %d\n", a);

    // Modulus assignment
    a %= b;  // equivalent to a = a % b
    printf("After a %%= b, a: %d\n", a);  // %% to escape %

    return 0;
}