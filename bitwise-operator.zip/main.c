#include <stdio.h>

int main() {
    int a = 5;  // 5 in binary: 0101
    int b = 3;  // 3 in binary: 0011

    // Bitwise AND
    printf("a & b: %d\n", a & b); // 0101 & 0011 = 0001 (1 in decimal)

    // Bitwise OR
    printf("a | b: %d\n", a | b); // 0101 | 0011 = 0111 (7 in decimal)

    // Bitwise XOR
    printf("a ^ b: %d\n", a ^ b); // 0101 ^ 0011 = 0110 (6 in decimal)

    // Bitwise NOT
    printf("~a: %d\n", ~a);       // ~0101 = 1010 (in two's complement: -6)

    // Left shift
    printf("a << 1: %d\n", a << 1); // 0101 << 1 = 1010 (10 in decimal)

    // Right shift
    printf("a >> 1: %d\n", a >> 1); // 0101 >> 1 = 0010 (2 in decimal)

    return 0;
}