#include <stdio.h>

int main() {
    int a = 10, b = 5;
    int max;

    // Ternary operator to find the maximum of a and b
    max = (a > b) ? a : b;
    printf("The maximum of %d and %d is: %d\n", a, b, max);

    // Using ternary operator to check if a number is even or odd
    int number = 7;
    const char* result = (number % 2 == 0) ? "even" : "odd";
    printf("The number %d is %s.\n", number, result);

    return 0;
}